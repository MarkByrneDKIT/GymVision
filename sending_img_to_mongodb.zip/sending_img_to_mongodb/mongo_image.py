from pymongo import MongoClient
import gridfs

connection = MongoClient('mongodb+srv://SetStatsAdmin:SetStats123@cluster0.cgmbyt4.mongodb.net/?retryWrites=true&w=majority')
database = connection['images']

fs = gridfs.GridFS(database)
file = "F:\Year 4\Project\Database Code Stuff\sending_img_to_mongodb/richard.jpg"

with open(file, 'rb') as f:
    contents = f.read()

fs.put(contents, filename="file")

#GridFS: It is used for storing and retrieving giant files like images, audios, videos, etc. In this, we have a tendency to store information in MongoDB collection. 
# It’s the potential to store files even bigger than the scale limit of 16MB.

# PyMongo: The PyMongo library is used to interacting with the MongoDB database from python.
#  We perform various functionality operations like retrieve results, write and delete data, run the database.